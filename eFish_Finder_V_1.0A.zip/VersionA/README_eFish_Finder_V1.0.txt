README_eFish_Finder_V1.0

Notes on PCB eFISH_finder_V1.0 (version A)

BATT = battery header (connector can be inserted with either polarity)
C = capacitor
CHGND = ground to chassis (solder pad to to ground chassis to the PCB)
INA = instrumentation op-amp
JP = jumper
R = resistor
SPK = speaker header (important: connector must be inserted with correct polarity!)

Notes on positions:
C3 (capacitor 3) is positioned below R7
C10 (capacitor 10) is positioned above JP1

JP1 jumper is DNC (do not connect). Currently pin 7 of the instrumentation op-amp is connected to ground only on high-gain.
By adding the female socket part to short circuit the two sides of this jumper, Pin 7 can be grounded on both high-gain and low-gain. 

For specifications of the four integrated circuits (INA, LM386, TLE, NE) see Components List